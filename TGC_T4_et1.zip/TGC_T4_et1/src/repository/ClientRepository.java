package repository;

import java.util.*;

import model.Client;
import exceptions.ClientNotFoundException;

public class ClientRepository implements IClientRepository {

    private List<Client> clienti = new ArrayList<>();

    @Override
    public void adaugaClient(Client c){
        clienti.add(c);
    }


    @Override
    public void eliminaClient(Client c){
        clienti.remove(c);
    }


    /*@Override
    public Client cautareClient(){
        System.out.println("Client - Cautare generala \nIntroduceti detalii (nume / venit / id partial sau complet): ");
        Scanner scan = new Scanner(System.in);
        String deCautat = scan.nextLine();
        Boolean gasit = false;

        while(gasit == false){

            for(int i=0; i < clienti.size(); i++) {
                gasit = false;

                if(clienti.get(i).getNume().toLowerCase().contains(deCautat.toLowerCase())) {
                    System.out.println("Client gasit. \n Detalii " + clienti.get(i).toString());
                    gasit = true;
                    Client found = clienti.get(i);

                }

            }
        }




        if(gasit == false)
            System.out.println("Nu s-a gasit client cu detaliile specificate");

        return found;

    }*/

    @Override
    public Client cautareClient(){
        //return statement luat din laborator 5

        System.out.println("Client - Cautare \nIntroduceti nume complet: ");
        Scanner scan = new Scanner(System.in);
        String deCautat = scan.nextLine();
        return clienti
                .stream()
                .filter(c -> c.getNume().equals(deCautat))
                .findFirst()
                .map(c -> c)
                .orElseThrow(ClientNotFoundException::new);
    }

    @Override
    public List<Client> getClienti(){
        return clienti;
    }

    @Override
    public void afisareClienti() {
        for(Client b:clienti)
            System.out.println(b);
    }

    public void sortareDupaSumaDePlata(){
        Collections.sort(clienti);
    }
}
