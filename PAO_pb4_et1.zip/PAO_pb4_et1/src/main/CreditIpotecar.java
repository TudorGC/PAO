package main;

public class CreditIpotecar extends Credit{

    private double valoareProprietate;

    public CreditIpotecar(double sumaInitiala, double procent, double valoareProprietate, int durata) {
        super(sumaInitiala, procent, durata);
        this.valoareProprietate = valoareProprietate;
        this.tipCredit = "Credit ipotecar";
    }

    @Override
    public String toString() {
        return "CreditIpotecar{" + super.toString() +
                "valoareProprietate=" + valoareProprietate +
                '}';
    }

    public double getValoareProprietate() {
        return valoareProprietate;
    }

    public void setValoareProprietate(double valoareProprietate) {
        this.valoareProprietate = valoareProprietate;
    }
}
