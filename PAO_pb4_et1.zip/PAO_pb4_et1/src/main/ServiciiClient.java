package main;

import java.util.Scanner;

public class ServiciiClient implements ServiciiDeBaza {


    public static void afisTranzactii(Credit unu){
        System.out.println(unu.istoricTranzactii);

    }


    public static void cautareTranzactie(Credit unu){

        System.out.println("Cautare generala \nIntroduceti detalii (tip tranzactie / suma (partial sau complet)");

        Scanner scan = new Scanner(System.in);
        String deCautat = scan.next();
        Boolean gasit = false;

        while(gasit == false){

            for(String s : unu.istoricTranzactii){
                gasit = false;

                if(s.toLowerCase().contains(deCautat.toLowerCase())) {
                    System.out.println("\n\nTranzactie gasita. \nDetalii tranzactie: " + s);
                    gasit = true;
                }
            }
        }
            if(gasit == false)
                System.out.println("Nu s-a gasit tranzactie cu detaliile specificate");

    }




    public static void interogareSold(Credit unu){
        System.out.println("Sold disponibil: " + unu.getSold());

    }


    public void actualizareDatePers(Client unu){
        //Scanner s = new Scanner(System.in);


    }

}
