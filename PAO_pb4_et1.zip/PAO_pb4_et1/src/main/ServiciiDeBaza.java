package main;

public interface ServiciiDeBaza {
    //public void afisCredite();
    public static void afisTranzactii(Credit unu){}
    public static void cautareTranzactie(Credit unu){}
    public static void interogareSold(Credit unu){}
    public static void actualizareDatePers(){}
}
