package main;

public class Card {

}
