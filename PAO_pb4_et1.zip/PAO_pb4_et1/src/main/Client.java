package main;

import java.util.ArrayList;
import java.util.List;

public class Client {
    private int cust_ID;
    private String nume;
    private int venit;
    Credit cred;
    //private ArrayList<Credit> =

    public Client(int cust_ID, String nume, int venit) {
        this.cust_ID = cust_ID;
        this.nume = nume;
        this.venit = venit;
    }

    public int getCust_ID() {

        return cust_ID;
    }

    public void setCust_ID(int cust_ID) {

        this.cust_ID = cust_ID;
    }

    public String getNume() {

        return nume;
    }

    public void setNume(String nume) {

        this.nume = nume;
    }

    public int getVenit() {

        return venit;
    }

    public void setVenit(int venit) {
        this.venit = venit;
    }

    @Override
    public String toString() {
        return "Client{" +
                "cust_ID=" + cust_ID +
                ", nume='" + nume + '\'' +
                ", venit=" + venit +
                '}';
    }
}
