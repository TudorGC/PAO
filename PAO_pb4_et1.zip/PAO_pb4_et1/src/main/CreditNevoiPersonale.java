package main;

public class CreditNevoiPersonale extends Credit {

    public CreditNevoiPersonale(double procentDobanda, double sumaInitiala, int durata) {

        super(procentDobanda, sumaInitiala, durata);
        this.tipCredit = "Credit nevoi personale";
    }
}
