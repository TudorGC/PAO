package main;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

public class ServiciiAdmin implements ServiciiAvansate{

    private ArrayList<Client> clienti = new ArrayList<Client>() ;

    @Override
    public void adaugaClient(){

        System.out.println("\n------------\nClient nou: ");
        String nume;
        int id, venit;

        System.out.println("Nume: ");
        Scanner input = new Scanner(System.in);
        nume = input.nextLine();

        System.out.println("venit: ");
        venit = input.nextInt();

        Random rand = new Random();
        id = rand.nextInt(10000);
        id +=1;


        clienti.add(new Client(id, nume, venit));

    }


    @Override
    public void eliminaClient(Client unu){
        clienti.remove(unu);
    }


    @Override
    public void cautareClient(){
        System.out.println("Cautare generala \nIntroduceti detalii (nume / venit / id partial sau complet): ");
        Scanner scan = new Scanner(System.in);
        String deCautat = scan.nextLine();
        Boolean gasit = false;

        while(gasit == false){

            for(int i=0; i < clienti.size(); i++) {
                gasit = false;

                if(clienti.get(i).getNume().toLowerCase().contains(deCautat.toLowerCase())) {
                    System.out.println("Client gasit. \n Detalii " + clienti.get(i).toString());
                    gasit = true;
                }
            }
        }

            if(gasit == false)
                System.out.println("Nu s-a gasit client cu detaliile specificate");

    }


    public void actualizareCredit(){

    }










    public void afisTranzactii(){

    }



    public void cautareTranzactie(String detalii){


    }



    public void interogareSold(){

    }


    public void actualizareDatePers(){

    }





}
