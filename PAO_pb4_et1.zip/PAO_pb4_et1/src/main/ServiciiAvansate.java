package main;

public interface ServiciiAvansate extends ServiciiDeBaza {

    public void adaugaClient();

    public void eliminaClient(Client unu);

    public void cautareClient();

    public void actualizareCredit();

}
