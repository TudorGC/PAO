package main;


import static main.ServiciiClient.cautareTranzactie;

public class Main {
    public static void main(String[] args) {

        Client John = new Client(1234, "John Doe", 7000);


        John.cred = new Credit(120000,5.5,60);
        John.cred.withdraw(1500);
        John.cred.withdraw(555);
        John.cred.afisIstoric();
        System.out.println(John.cred.getRata());

        ServiciiAdmin admin = new ServiciiAdmin();
        admin.adaugaClient();
        admin.adaugaClient();
        admin.adaugaClient();

        admin.cautareClient();

        cautareTranzactie(John.cred);


    }
}
